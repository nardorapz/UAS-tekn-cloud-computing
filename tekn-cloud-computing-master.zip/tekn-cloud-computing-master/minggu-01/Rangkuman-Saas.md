1. perbedaan  
Saas 
	saas merupakn digunakan menjalankan aplikasi di cloud publik. Pengguna menggunakan aplikasi ini melalui Internet. Aplikasi ini dikelola oleh Penyedia Layanan. Beberapa mis., Penyedia Layanan, adalah SalesForce, Microsoft (Office 365), Oracle, Google (Google Apps), dll. Salesforce adalah perusahaan pertama yang mengubah dunia Saas, dan sejak saat itu, perusahaan lain telah melihat potensi di pasar ini dan meluncurkan aplikasi mereka.

iaas
	Ini memberikan lingkungan bagi pengembang untuk membangun aplikasi yang dapat digunakan pengguna. IaaS meliputi: -

	Pengguna membuat mesin virtual (VM) sesuai permintaan.
	Dari perpustakaan gambar VM.
	Amazon (AWS) adalah vendor terkemuka dalam menyediakan IaaS.

PaaS: 
Platform sebagai Layanan

	Ini agak mirip dengan IaaS tetapi perbedaannya adalah:
	Pengembang menyediakan aplikasi yang dijalankan platform.
	Mereka tidak secara langsung membuat VM. Anda akan berpikir bahwa PaaS sederhana dan itulah sebabnya banyak digunakan. 
	Tetapi ini tidak benar. IaaS adalah 10 kali populer dari PaaS. Pengembang ingin memiliki kontrol lebih besar atas sumber daya.


2. saas platform archictertur

Dengan model ini, satu versi aplikasi, dengan satu konfigurasi digunakan untuk semua pelanggan. Aplikasi ini diinstal pada banyak mesin untuk mendukung skalabilitas (disebut penskalaan horizontal). Dalam beberapa kasus, versi kedua aplikasi diatur untuk menawarkan kelompok pelanggan tertentu dengan akses ke versi pra-rilis aplikasi untuk tujuan pengujian. Dalam model tradisional ini, setiap versi aplikasi didasarkan pada kode unik. Meskipun pengecualian, beberapa solusi SaaS tidak menggunakan multitenancy, untuk mengelola secara efektif sejumlah besar pelanggan di tempat. Apakah multitenancy merupakan komponen yang diperlukan untuk perangkat lunak-sebagai-layanan adalah topik kontroversi.

3. Dengan model ini, satu versi aplikasi, dengan satu konfigurasi digunakan untuk semua pelanggan. Aplikasi ini diinstal pada banyak mesin untuk mendukung skalabilitas (disebut penskalaan horizontal). Dalam beberapa kasus, versi kedua aplikasi diatur untuk menawarkan kelompok pelanggan tertentu dengan akses ke versi pra-rilis aplikasi untuk tujuan pengujian. Dalam model tradisional ini, setiap versi aplikasi didasarkan pada kode unik. Meskipun pengecualian, beberapa solusi SaaS tidak menggunakan multitenancy, untuk mengelola secara efektif sejumlah besar pelanggan di tempat. Apakah multitenancy merupakan komponen yang diperlukan untuk perangkat lunak-sebagai-layanan adalah topik kontroversi.
  1. bahasa program 
  	Bahasa pemrograman mana, basis data apa, alat perangkat lunak apa yang harus Anda pilih? Ada banyak pertanyaan yang perlu dijawab. Karenanya saya mencoba fokus pada hal-hal terpenting. yang terdiri dari Python adalah bahasa pemrograman yang banyak digunakan, dirancang untuk menekankan keterbacaan kode-nya.
  2. RabbitMQ
  		RabbitMQ adalah sistem antrian sumber terbuka yang berjalan pada semua sistem operasi utama.


jadi dapatb saya simpulkan bahwa iaas, saas, paas menrupakan Perusahaan sebaiknya mempertimbangkan fleksibilitas dan implikasi manajemen risiko dalam menambahkan SaaS ke portofolio layanan TI mereka. Integrasi dan komposisi adalah komponen penting dalam strategi arsitektur Anda untuk menggabungkan SaaS dengan sukses sebagai anggota yang berpartisipasi penuh dari infrastruktur TI Anda yang berpusat pada layanan. Kami percaya bahwa masa depan komputasi perusahaan tidak akan murni di tempat. Sebaliknya, mereka akan ada dalam harmoni simbiosis.