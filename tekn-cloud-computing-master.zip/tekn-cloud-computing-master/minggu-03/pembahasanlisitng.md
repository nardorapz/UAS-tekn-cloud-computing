![gambar1](minggu-03/S1.png)
pada tampilan berikut masih melanjutkan program instal aplikasi sebelumnya. artinya apalikasi yang sudah terinstal.

![gambar2](minggu-03/S2.PNG)
pada tampilan pada gambar 4 merupakan tampilan untuk melakukan perintah login heroku.


![gambar3](minggu-03/S3.PNG)
tampilan berikut merupakan perintah heroku login tersebuat akan menampilkan seperti gambar berikut. artinya apabila sudah menampilkan seperti ini kita akan mengklik log in supaya apilkasi heroku tersebut bisa di jalankan.


![gambar4](minggu-03/S4.PNG)
setelah itu akan di lakukan perintah git clone, sehingga bisa tersimpannya Repostory kita yang sudah buat.

![gambar5](minggu-03/S5.png)
setelah itu akan dilakukan perintah heroku create artinya kita akan membuat sebuah project baru pada akun heroku yang kita buat.

![gambar6](minggu-03/S6.JPG)
pada perintah git  push heroku master untuk mengupload file yang sudah di buat pada akun heroku.


![gambar7](minggu-03/S7.JPG)
Menjalankan heroku ps:scale web=1 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.

![gambar8](minggu-03/S8.JPG)
perintah heroku open merupakan perintah dimana apbila kita ingin mebuka akun heroku kita.





![gambar9](minggu-03/S9.JPG)
Akses lagi aplikasi dengan menekan refresh pada tab web, atau heroku terbuka untuk membukanya di tab web. Anda akan mendapatkan pesan kesalahan karena Anda tidak lagi memiliki dinamika web yang tersedia untuk melayani permintaan.


![gambar10](minggu-03/S10.JPG)

Akses lagi aplikasi dengan menekan refresh pada tab web, atau heroku terbuka untuk membukanya di tab web. Anda akan mendapatkan pesan kesalahan karena Anda tidak lagi memiliki dinamika web yang tersedia untuk melayani permintaan. Menjalankan heroku ps:scale web=1 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.

![gambar11](minggu-03/S11.JPG)
Menjalankan heroku ps:scale web=0 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.
![gambar12](minggu-03/S12.JPG)

Satu lagi kelebihan dari pip adalah, and bisa membuat satu list package yang anda ingin install dengan menuliskannya di txt file, contoh jika anda ingin menggunakan komputer yang berbeda dan di komputer tersebut belum ada packages yang terinstall, anda hanya perlu me-run txt file tersebut dengan mengikuti cara ini. Masih banyak command-command lain yang tersedia, untuk lebih jelasnya bisa lihat di dokumentasinya.