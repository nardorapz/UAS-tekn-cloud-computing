![gambar1](minggu-03/tugas/g1.PNG)
pada tampilan pada gambar 4 merupakan tampilan untuk melakukan perintah login heroku.
serta menjalnakan perintah composer versi dan menjalankan git version dan php version.


![gambar2](minggu-03/tugas/g2.PNG)
tampilan berikut merupakan perintah heroku login tersebuat akan menampilkan seperti gambar berikut. artinya apabila sudah menampilkan seperti ini kita akan mengklik log in supaya apilkasi heroku tersebut bisa di jalankan.


![gambar3](minggu-03/tugas/g3.PNG)
setelah itu akan di lakukan perintah git push heroku mster, sehingga bisa tersimpannya Repostory kita yang sudah buat.

![gambar4](minggu-03/tugas/g4.png)
Menjalankan heroku ps:scale web=1 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.setelah itu akan dilakukan perintah heroku create artinya kita akan membuat sebuah project baru pada akun heroku yang kita buat.

![gambar5](minggu-03/tugas/g5.png)
pada perintah yang menjalanakan file yang sudah di buat pada akun heroku.


![gambar7](minggu-03/tugas/g6.png)
Menjalankan heroku ps:scale web=1 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.

![gambar8](minggu-03/tugas/g8.png)
Menjalankan heroku ps:scale web=1 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.



![gambar9](minggu-03/tugas/g9.png)
Menjalankan heroku ps:scale web=0 akan mengatur skala aplikasi Anda menjadi satu menjalankan dyno, pada dasarnya berarti Anda memiliki satu server yang menjalankan aplikasi Anda saat ini.
![gambar10](minggu-03/tugas/g10.png)
mengupdate composer yang sudah di install sebelumnya