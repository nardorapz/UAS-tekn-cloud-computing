<h1> Rangkuman Saas </h1>

1. [rangkuman Saas](/minggu-02/rangkuman-saas.md)

2. [Penjelasan Saas](/minggu-02/layanan-saas.md)


